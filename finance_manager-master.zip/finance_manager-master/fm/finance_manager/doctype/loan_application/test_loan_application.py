# -*- coding: utf-8 -*-
# Copyright (c) 2017, Soldeva, SRL and Contributors
# See license.txt
from __future__ import unicode_literals

import frappe
import unittest

class TestLoanApplication(unittest.TestCase):
	pass
