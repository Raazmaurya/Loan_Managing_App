# -*- coding: utf-8 -*-
# Copyright (c) 2017, Yefri Tavarez and Contributors
# See license.txt
from __future__ import unicode_literals

import frappe
import unittest

class TestAmortizationTool(unittest.TestCase):
	pass
