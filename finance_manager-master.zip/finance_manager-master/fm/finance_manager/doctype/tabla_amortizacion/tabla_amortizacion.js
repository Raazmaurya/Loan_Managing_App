// Copyright (c) 2017, Soldeva, SRL and contributors
// For license information, please see license.txt

frappe.ui.form.on("Tabla Amortizacion", {
	refresh: function(frm) {
		// toDo
	} 
});