// Copyright (c) 2016, Soldeva, SRL and contributors
// For license information, please see license.txt

frappe.ui.form.on('Cashier Closing Entry', {
	refresh: function(frm) {

	}
});
